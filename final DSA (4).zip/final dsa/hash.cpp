#include<iostream>
#include<string.h>
#define max 10
using namespace std;

struct node {
    char name[10];
    long int mn;
    int chain;
    node() {
        mn = 0;
        chain = -1;
        strcpy(name, "-----");
    }
};

class telephone {
public:
    node ht[max];
    int count;

    telephone() {
        count = 0;
    }

    int hashfun(long int);
    void insert();
    void find();
    void display();
    void delno();
};

int telephone::hashfun(long int num) {
    return (num % 10);
}

void telephone::insert() {
    node s;
    int ind;
    cout << "Enter name and telephone number: \n";
    cin >> s.name >> s.mn;
    ind = hashfun(s.mn);
    cout << "Index= " << ind << endl;
    if (ht[ind].mn == 0) {
        ht[ind] = s;
        count++;
    } else if (ind == hashfun(ht[ind].mn)) {
        int prev = ind;
        while (ht[ind].mn != 0) {
            prev = ind;
            ind = (ind + 1) % max;
        }
        ht[ind] = s;
        ht[prev].chain = ind;
        count++;
    } else {
        node replaced;
        replaced = ht[ind];
        ht[ind] = s;
        while (ht[ind].mn != 0)
            ind = (ind + 1) % max;
        ht[ind] = replaced;
        int x = hashfun(replaced.mn);
        int oriind = x;
        while (ht[x].chain != -1) {
            x = ht[x].chain;
            if (ht[x].chain != -1)
                oriind = x;
        }
        if (hashfun(ht[x].mn) == oriind)
            ht[x].chain = ind;
        else
            ht[oriind].chain = ind;
        count++;
    }
}

void telephone::find() {
    long int num;
    cout << "Enter telephone number to find: ";
    cin >> num;
    int ind = hashfun(num);
    int start = ind;
    while (start != -1 && ht[start].mn != num)
        start = ht[start].chain;
    if (start == -1)
        cout << "Number not found." << endl;
    else
        cout << "Name: " << ht[start].name << endl;
}

void telephone::delno() {
    long int num;
    cout << "Enter telephone number to delete: ";
    cin >> num;
    int ind = hashfun(num);
    int start = ind;
    int prev = -1;
    while (start != -1 && ht[start].mn != num) {
        prev = start;
        start = ht[start].chain;
    }
    if (start == -1)
        cout << "Number not found." << endl;
    else {
        if (prev != -1)
            ht[prev].chain = ht[start].chain;
        else
            ht[ind] = node();
        cout << "Number deleted." << endl;
    }
}

void telephone::display() {
    for (int i = 0; i < max; i++) {
        cout << i << "\t" << ht[i].name << "\t" << ht[i].mn << "\t" << ht[i].chain << endl;
    }
}

int main() {
    telephone t;
    int ch;
    char ans;
    do {
        cout << "Enter your choice" << endl;
        cout << "1.Insert" << endl;
        cout << "2.Find" << endl;
        cout << "3.Delete" << endl;
        cout << "4.Display" << endl;
        cin >> ch;
        switch (ch) {
            case 1:
                t.insert();
                break;
            case 2:
                t.find();
                break;
            case 3:
                t.delno();
                break;
            case 4:
                t.display();
                break;
            default:
                cout << "Invalid choice!!";
        }
        cout << "Do you want to continue? (y/n)";
        cin >> ans;
    } while (ans == 'y' || ans == 'Y');
    return 0;
}
