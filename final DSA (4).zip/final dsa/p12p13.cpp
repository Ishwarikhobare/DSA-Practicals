#include<iostream>
#include<string.h>
using namespace std;

class dict
{
    char word[20],mean[50],newMean[50];
    dict *left,*right;
    int ht;

public:
    dict* create(dict *root);
    dict* insert(dict* root,char w[],char m[]);
    void display(dict*);
    int height(dict*);
    dict* search(dict* root,char w[]);
    dict* update(dict* root,char w[],char nm[]);
    dict* minValue(dict* root,char w[]);
    dict* deleteNode(dict* root,char w[]);
    dict* rotateright(dict*);
    dict* rotateleft(dict*);
    int BF(dict*);
    dict* RR(dict*);
    dict* LL(dict*);
    dict* RL(dict*);
    dict* LR(dict*);
};

dict* dict::create(dict* root)
{
    int n,i;
    char w[20],m[50];
    cout<<"\nEnter total number of words:";
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<"\nEnter word "<<i+1<<":";
        cin>>w;
        cout<<"\nEnter meaning:";
        cin>>m;
        root=insert(root,w,m);
    }
    return root;
}

dict* dict::insert(dict* root,char w[],char m[])
{
    if(root==NULL)
    {
        root=new dict;
        strcpy(root->word,w);
        strcpy(root->mean,m);
        root->left=NULL	;
        root->right=NULL;
        return root;
    }
    else
    {
        if(strcmp(w,root->word)>0)
        {
            root->right=insert(root->right,w,m);
            if(BF(root)==-2)
            {
                if(strcmp(w,root->word)>0)
                    root=RR(root);
                else
                    root=RL(root);
            }
        }
        else
        {
            if(strcmp(w,root->word)<0)
            {
                root->left=insert(root->left,w,m);
                if(BF(root)==2)
                {
                    if(strcmp(w,root->word)<0)
                        root=LL(root);
                    else
                        root=LR(root);
                }
            }	
        }
    }

    root->ht=height(root);
    return root;
}

void dict::display(dict* root)
{
    if(root!=NULL)
    {
        display(root->left);
        cout<<"\nNode is:"<<root->word<<"-"<<root->mean;
        display(root->right);
    }
}

int dict::height(dict* root)
{
    int lh,rh;
    if(root==NULL)
        return 0;
    if(root->left==NULL)
        lh=0;
    else
        lh=1+root->left->ht;
    if(root->right==NULL)
        rh=0;
    else
        rh=1+root->right->ht;

    if(lh>rh)
    {
        return(lh);
    }
    else
    {
        return(rh);
    }
}

dict* dict::search(dict* root,char w[])
{
    if(root==NULL)
        cout<<"Tree is empty";
    else if(strcmp(root->word,w)==0)
        cout<<"\n searched node is:"<<root->word<<"-"<<root->mean;
    else if(strcmp(root->word,w)>0)
    {	
        search(root->left,w);
        cout<<"\nSearched node is:"<<root->word<<"-"<<root->mean;
    }
    else
    {	
        search(root->right,w);
        cout<<"\nSearched node is:"<<root->word<<"-"<<root->mean;
    }
}

dict* dict::update(dict* root,char w[],char nm[])
{
    root=deleteNode(root,w);
    root=insert(root,w,nm);
    cout<<"Updated word with its new meaning:"<<w<<"-"<<nm;
    return root;
}

dict* dict::minValue(dict* root,char w[])
{
    root=minValue(root,w);
    return root;
}

dict* dict::deleteNode(dict* root,char w[])
{
    if(root==NULL)
        return root;
    else
    {
        if(strcmp(w,root->word)<0)
            root->left=deleteNode(root->left,w);
        else if(strcmp(w,root->word)>0)
            root->right=deleteNode(root->right,w);
        else
        {
            if(root->left==NULL||root->right==NULL)
            {
                dict* temp;
                temp=root->left?root->left:root->right;
                if(temp==NULL)
                {
                    temp=root;
                    root=NULL;
                }
                else
                    *root=*temp;
                delete temp;
            }
            else
            {
                dict* temp;
                temp=minValue(root->right,w);
                strcpy(root->word,temp->word);
                strcpy(root->mean,temp->mean);
                root->right=deleteNode(root->right,temp->word);
            }
        }
    }
    return root;
}

dict* dict::rotateright(dict *x)
{
    dict *y;
    y=x->left;
    x->left=y->right;
    y->right=x;
    x->ht=height(x);
    y->ht=height(y);
    return(y);
}

dict* dict::rotateleft(dict *x)
{
    dict *y;
    y=x->right;
    x->right=y->left;
    y->left=x;
    x->ht=height(x);
    y->ht=height(y);
    return(y);
}

int dict::BF(dict* root)
{
    int lh,rh;
    if(root==NULL)
        return(0);
    if(root->left==NULL)
        lh=0;
    else
        lh=1+root->left->ht;
    if(root->right==NULL)
        rh=0;
    else
        rh=1+root->right->ht;
    int z=lh-rh;
    return(z);
}

dict* dict::RR(dict *T)
{
    T=rotateleft(T);
    return(T);
}

dict* dict::LL(dict *T)
{
    T=rotateright(T);
    return(T);
}

dict* dict::LR(dict *T)
{
    T->left=rotateleft(T->left);
    T=rotateright(T);
    return(T);
}

dict* dict::RL(dict *T)
{
    T->right=rotateright(T->left);
    T=rotateleft(T);
    return(T);
}

int main()
{
    int ch;
    dict d,*root;
    root=NULL;
    char w[20],m[50],nm[50];
    cout<<"\n****DICTIONARY AVL****";

    do
    {
        cout<<"\n\nMENU:";
        cout<<"\n1.CREATE\n2.INSERT\n3.Display\n4.Search\n5.Update\n6.Delete";
        cout<<"\nEnter your choice:";
        cin>>ch;

        switch(ch)
        {
            case 1:
                root=d.create(root);
                break;

            case 2:
                cout<<"\nEnter word:";
                cin>>w;
                cout<<"\nEnter meaning:";
                cin>>m;
                root=d.insert(root,w,m);
                break;

            case 3:
                d.display(root);
                break;

            case 4:
                cout<<"Enter the word you want to search:";
                cin>>w;
                d.search(root,w);
                break;

            case 5:
                cout<<"Enter the word whose meaning you want to update:";
                cin>>w;
                cout<<"Enter new meaning:";
                cin>>nm;
                root=d.update(root,w,nm);
                break;

            case 6:
                cout<<"Enter the word you want to delete:";
                cin>>w;
                d.deleteNode(root,w);
                cout<<"Node deleted successfully";
                break;

            default:
                cout<<"\nInvalid choice!!";
        }
    }
    while(ch!=7);
    return 0;
}
