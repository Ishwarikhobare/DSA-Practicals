#include<iostream>
#include<string.h>
#define max 10
using namespace std;

struct node
{
    char name[10];
    long int mn;
    node()
    {
        mn = 0;
        strcpy(name, "--------");
    }
};

class telephone
{
public:
    node h[max];
    node ht[max];
   
    int hashfun(long int);
    void Insert();
    void insert();
    //void find();
    void display();
    void Display();
    //void delno();
    int linearProbe(long int);
    int quadraticProbe(long int);
};

int telephone::hashfun(long int num)
{
    return (num % 10);
}

int telephone::linearProbe(long int num)
{
    int ind = hashfun(num);
    int comparisons = 1;

    while (h[ind].mn != num && h[ind].mn != 0) {
        ind = (ind + 1) % max;
        comparisons++;
    }

    return comparisons;
}

int telephone::quadraticProbe(long int num)
{
    int ind = hashfun(num);
    int comparisons = 1;
    int i = 1;

    while (h[ind].mn != num && h[ind].mn != 0) {
        ind = (ind + i * i) % max;
        i++;
        comparisons++;
    }

    return comparisons;
}


void telephone::Insert()
{
    node s1;
    int ind;
    cout << "**DATA FOR LINEAR PROBING**" << endl;
    cout << "Enter name:";
    cin >> s1.name;
    cout << "Enter telephone number:";
    cin >> s1.mn;
    ind = hashfun(s1.mn);
    if (h[ind].mn == 0)
    {
        h[ind] = s1;
    }
    else
    {
        // Linear probing
        int i = 1;
        int newIndex = (ind + i) % max; // Calculate the new index
        while (h[newIndex].mn != 0 && newIndex != ind) // Continue until an empty slot or back to the original index
        {
            i++;
            newIndex = (ind + i) % max; // Recalculate the new index
        }
        if (newIndex != ind) // If we found an empty slot
        {
            h[newIndex] = s1;
        }
        else
        {
            cout << "Hash table is full, cannot insert." << endl;
        }
    }
}

void telephone::Display()
{
    for (int i = 0; i < max; i++)
    {
        cout << i << "\t" << h[i].name << "\t" << h[i].mn << endl;
    }
}

void telephone::insert()
{
    node s;
    int ind;
    long int m;
    cout << "enter name and telephone no.:" << endl;
    cin >> s.name >> s.mn;
    m = s.mn;
    ind = hashfun(s.mn);
    cout << "index:" << ind << endl;
    if (ht[ind].mn == 0)
    {
        ht[ind] = s;
    }
    else
    {
        int i = 1;
        while (ht[ind].mn != 0)
        {
            ind = (m + (i * i));
            ind = ind % max;
            i++;
        }
        ht[ind] = s;
    }
}

void telephone::display()
{
    for (int i = 0; i < max; i++)
    {
        cout << i << "\t" << ht[i].name << "\t" << ht[i].mn << endl;
    }
}

int main()
{
    telephone t;
    int ch;
    char ans;
    do
    {
        cout << "enter your choice" << endl;
        cout << "1. Linear insert" << endl;
        cout << "2. Display for linear" << endl;
        cout << "3. Insert" << endl;
        cout << "4. Display" << endl;
        cout << "5. Compare linear and quadratic probing" << endl;
        cin >> ch;
        switch (ch)
        {
        case 1:
            t.Insert();
            break;
        case 2:
            t.Display();
            break;
        case 3:
            t.insert();
            break;
        case 4:
            t.display();
            break;
        case 5:
            {
                long int phoneNumber;
                cout << "Enter telephone number to search: ";
                cin >> phoneNumber;
                int linearComparisons = t.linearProbe(phoneNumber);
                int quadraticComparisons = t.quadraticProbe(phoneNumber);
                cout << "Linear probing comparisons: " << linearComparisons << endl;
                cout << "Quadratic probing comparisons: " << quadraticComparisons << endl;
            }
            break;
        default:
            cout << "Invalid choice!!!" << endl;
        }
        cout << "Do you want to continue? (y/n)";
        cin >> ans;
    } while (ans == 'y');
    return 0;
}
