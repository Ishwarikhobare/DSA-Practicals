#include<iostream>
#include<stack>
using namespace std;

int n, visited[10], g[10][10];

// Function prototypes
void dfs_recursive(int);
void dfs_non_recursive(int);

int main()
{
    int i, j, v;
    cout << "Enter the number of vertices: ";
    cin >> n;
    
    cout << "Enter the adjacency matrix: ";
    for(i = 1; i <= n; i++)
    {
        for(j = 1; j <= n; j++)
        {
            cin >> g[i][j];
        }
    }
    
    cout << "Matrix is:" << endl;
    for(i = 1; i <= n; i++)
    {
        for(j = 1; j <= n; j++)
        {
            cout << g[i][j] << "\t";
        }
        cout << endl;
    }
    
    cout << "Enter a node to search from: ";
    cin >> v;
    
    // Initialize visited array
    for(i = 1; i <= n; i++)
    {
        visited[i] = 0;
    }
    
    cout << "DFS Recursive: ";
    dfs_recursive(v);
    cout << endl;
    
    // Reset visited array
    for(i = 1; i <= n; i++)
    {
        visited[i] = 0;
    }
    
    cout << "DFS Non-Recursive: ";
    dfs_non_recursive(v);
    cout << endl;

    return 0;
}

// Recursive DFS function
void dfs_recursive(int v)
{
    visited[v] = 1;
    cout << v << " ";
    for(int i = 1; i <= n; i++)
    {
        if(g[v][i] == 1 && visited[i] == 0)
        {
            dfs_recursive(i);
        }
    }
}

// Non-Recursive DFS function
void dfs_non_recursive(int v)
{
    stack<int> stk;
    stk.push(v);
    
    while(!stk.empty())
    {
        v = stk.top();
        stk.pop();
        
        //if(visited[v] == 0)
        //{
            cout << v << " ";
            visited[v] = 1;
            for(int i = 1; i <= n; i++)
            {
                if(g[v][i] == 1&& visited[i]==0)
                {
                    stk.push(i);
                }
            }
       // }
    }
}
