
#include<iostream>
using namespace std;

#define max 10

struct node
{
    string name;
    long mn;
    node *next;
};

class telp
{
    node *arr[max];
public:
    int hashf(long int);
    void insert();
    void disp();
    void find();
    void remove(); // Declaration of remove() function

    telp()
    {
        for(int i=0;i<max;i++)
            arr[i]=NULL;
    }
};

int telp::hashf(long int num)
{
    return(num % max); // Changed to use the max size defined
}

void telp::insert()
{
    int ind;
    node *nn;
    nn=new node;
    cout<<"Enter name and contact no.: ";
    cin>>nn->name;
    cin>>nn->mn;
    nn->next=NULL;
    ind=hashf(nn->mn);
    if(arr[ind]==NULL)
    {
        arr[ind]=nn;
    }
    else
    {
        node *temp=arr[ind];
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp->next=nn;
    }
}

void telp::disp()
{
    for(int i=0;i<max;i++)
    {
        node *temp=arr[i];
        if(temp==NULL)
            cout<<i<<"--->NULL"<<endl;
        else
        {
            if(temp->next==NULL)
                cout<<i<<"--->"<<temp->mn<<endl;
            else
            {
                cout<<i<<"--->";
                while(temp->next!=NULL)
                {
                    cout<<temp->mn<<"-->";
                    temp=temp->next;
                }
                cout<<temp->mn<<endl;
            }
        }
    }
}

void telp::find()
{
    string name;
    cout << "Enter the name to find: ";
    cin >> name;
    bool found = false;
    for(int i = 0; i < max; i++)
    {
        node *temp = arr[i];
        while(temp != NULL)
        {
            if(temp->name == name)
            {
                cout << "Telephone number of " << name << " is: " << temp->mn << endl;
                found = true;
                break;
            }
            temp = temp->next;
        }
        if(found)
            break;
    }
    if(!found)
        cout << "Name not found in the directory." << endl;
}

void telp::remove()
{
    string name;
    cout << "Enter the name to remove: ";
    cin >> name;
    for(int i = 0; i < max; i++)
    {
        node *current = arr[i];
        node *prev = NULL;
        while(current != NULL)
        {
            if(current->name == name)
            {
                if(prev == NULL) // If the node to be deleted is the head of the list
                {
                    arr[i] = current->next;
                    delete current;
                    return;
                }
                prev->next = current->next;
                delete current;
                return;
            }
            prev = current;
            current = current->next;
        }
    }
    cout << "Name not found in the directory. No deletion performed." << endl;
}

int main()
{
    telp t;
    int ch;
    do
    {
        cout<<endl<<"1.insert\t2.disp\t3.find\t4.remove\t0.exit"<<endl;
        cout<<"enter choice: ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                t.insert();
                break;
            case 2:
                t.disp();
                break;
            case 3:
                t.find();
                break;
            case 4:
                t.remove();
                break;
            case 0:
                cout<<"Exiting..."<<endl;
                break;
            default:
                cout<<"Invalid Choice!!!!";
                break;
        }
    }while(ch!=0);
    return 0;
}
