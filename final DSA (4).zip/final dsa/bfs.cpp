#include <iostream>
#include <queue> // Include queue for BFS traversal
using namespace std;

struct node
{
    int data;
    node *next;
};

class BFS
{
public:
    int n;
    node *adjlist[10];
    void create();
    void display();
    void bfsTraversal(int start);
};

void BFS::create()
{
    cout << "Enter number of nodes: ";
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        adjlist[i] = new node; // Allocate memory for each adjacency list node
        adjlist[i]->next = NULL;
        int nb;
        cout << "Enter number of neighbours to node " << i << ": ";
        cin >> nb;
        cout << "\n";
        node *last = NULL; // Initialize last pointer
        for (int j = 0; j < nb; j++)
        {
            node *nn = new node; // Allocate memory for the new neighbour node
            nn->next = NULL;
            cout << "Enter name of neighbour node: ";
            cin >> nn->data;
            if (adjlist[i]->next == NULL)
            {
                adjlist[i]->next = nn;
                last = nn; // Update last pointer
            }
            else
            {
                last->next = nn;
                last = nn; // Update last pointer
            }
        }
    }
}

void BFS::display()
{
    for (int i = 0; i < n; i++)
    {
        node *current = adjlist[i]->next; // Start from the first neighbour node
        cout << "Node " << i << " neighbours: ";
        while (current != NULL)
        {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
}

void BFS::bfsTraversal(int start)
{
    bool visited[n] = {false}; // Array to keep track of visited nodes
    queue<int> q; // Queue for BFS traversal

    visited[start] = true; // Mark the start node as visited
    q.push(start); // Push start node into the queue

    while (!q.empty())
    {
        int current = q.front(); // Get the front element of the queue
        q.pop(); // Remove the front element

        cout << current << " "; // Print the current node

        // Traverse through all the neighbours of the current node
        node *temp = adjlist[current]->next;
        while (temp != NULL)
        {
            if (!visited[temp->data])
            {
                visited[temp->data] = true; // Mark the neighbour as visited
                q.push(temp->data); // Push the neighbour into the queue
            }
            temp = temp->next;
        }
    }
}

int main()
{
    BFS n;
    n.create();
    n.display();

    int startNode;
    cout << "Enter the starting node for BFS traversal: ";
    cin >> startNode;
    cout << "BFS Traversal: ";
    n.bfsTraversal(startNode);

    return 0;
}
 